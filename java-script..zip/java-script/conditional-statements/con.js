// let a = false;
// if (!a) {
//   console.log("hii");
// }
// else {
//   console.log("bye");
// 1. Create a prompt to ask the user's age
let age = prompt("Enter your age");
// 2. Convert the response from the prompt to a number
age = Number(age);
console.log(age, typeof (age));
// 3. Declare a message variable that you will use to hold the console message for
// the user
let message;
// 4. If the input age is equal to or greater than 21, set the message variable to
// conrm entry to a venue and the ability to purchase alcohol
if (age >= 21) {
  message = "confirm enter to a venue and able to purchase alcohol";
}
// 5. If the input age is equal to or greater than 19, set the message variable to
// conrm entry to the venue but deny the purchase o alcohol
else if (age >= 19) {
  message = " confirm entry to venue but deny the purchase alochol";
}
// 6. Provide a default else statement to set the message variable to deny entry if
// none are true
else {
  message = " deny entry ";
}
// 7. Output the response message variable to the console}
console.log(message);
