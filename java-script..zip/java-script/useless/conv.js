let nr1 = 2;
let nr2 = "2";
console.log(nr1+nr2 , typeof(nr1+nr2));


