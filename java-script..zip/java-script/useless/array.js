// creating an empty array to use as a shopping list
let arr = []; // declare an empty array
// Add milk, Bread, and Apples
console.log(arr);
arr.push("Milk");
arr.push("Bread");
arr.push("Apple");
console.log(arr);
// update "Bread" with Bananas
arr[1] = "Banana";
console.log(arr);
// Remove the last item from the array and output it into the console
arr.pop();
console.log(arr);
//sorting alphabetically
arr.sort();
console.log(arr);
//find and output the index value of Milk
let find = arr.indexOf("Milk");
console.log(find);
//After Bananas add carrots and lettuce
arr.splice(1, 0, "carrots", "lettuce");
console.log(arr);
//creating a new array //add juice and pop
let n = ["juice", "pop"];
console.log(n);
//combine both lists, add new list twice at end of the first
let con = arr.concat(n, n);
console.log(con);
//get the last index value of a pop and output it to the console
let f = con.indexOf("pop");
console.log(f);
//print the array
console.log(con);
