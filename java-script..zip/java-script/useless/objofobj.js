let company = {
  companyName: "Amul",
  activity: "Milk Supply",
  address: {
    street: "2nd street",
    number: "123",
    zipcode: 221010,
    city: "Varanasi",
    state: "Uttar Pradesh",
  },
  foundation: 1947,
};

let a = company.address.state;
console.log(a);
