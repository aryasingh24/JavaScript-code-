// creating 
let biodata = {
  firstname: "Arya",
  secondname: "Singh",
  age: 24,
  weight: 80,
}

//calling
let bio = biodata.firstname;
console.log(bio);

//update

biodata["firstname"] = "tannu";
console.log(biodata);
biodata["age"] = 25;
console.log(biodata);


// datatype change 
biodata["age"] = "twentyfour";
console.log(biodata);
