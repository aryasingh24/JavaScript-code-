let nr1 = 12;
var nr2 = 8;
//const sameConstant = 3;
//sameConstant = 4;
console.log(nr1);
console.log(nr2);
//console.log(sameConstant);



