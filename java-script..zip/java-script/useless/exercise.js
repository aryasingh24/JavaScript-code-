// 1. Create an object named people that contains an empty array that is called
// friends.
let people = {
  friend: [],
};
// 2. Create three variables, each containing an object, that contain one of your
let a = {
  firstn: "Arya",
  lastn: "Singh",
  id: "MCA2322009",
};
// friend's first names, last names, and an ID value.
// 3. Add the three friends to the friend array.
people.friend.push(a);
console.log(people);
// 4. Output it to the console.
//
