//creating a var that contain a value in miles, convert it to kilometers
//
// let km = 130;
// let m = km * 1.6;
// let message = ` This distance of 130 kms ${km} is ${m} miles`
// console.log(message)
//
//
//
//set a value for height in inches & weight in pound then, set them to centimeter & kilos
//
// let hIn = 60; // height in inches
// hcm = hIn * 2.54; //height in centimeter
// hm = hcm / 100; //height in meter
// let wp = 130; //weight in pounds
// wk = wp / 2.2; // weight in kilos
// let bmi = wp / (hm * hm);
// let message = `bmi for body height ${hIn} in inches and weight ${wp} in pounds is  this ${bmi}`;
// console.log(message);

//print random number on alert to get pop up, so it seems like OTP............

let a = Math.random();

alert("OTP" + a);
