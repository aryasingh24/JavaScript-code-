let address = [
  {
    street: "2nd street",
    number: "123",
    zipcode: 221010,
    city: "Varanasi",
    state: "Uttar Pradesh",
  },
  {
    street: "kanpur street",
    number: "12",
    zipcode: 24321,
    city: "kanpur",
    state: "Uttar Pradesh",
  },
];

let a = address[1].number;
console.log(a);
