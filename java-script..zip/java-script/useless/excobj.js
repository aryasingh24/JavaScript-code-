//Create a newmyCarobject for a car. Add some properties, including, but not
//limited to, makeand model, and values for a typical car or your car. Feel free
//to use booleans, strings, or numbers.


let car = {
  carName: "ford",
  model: "ecosport",
  wheels: 4,
}

console.log(car);

//Create a variable that can hold the string value
// //color . This variable
// containing a string value color can now be used to reference the property
// name within myCar. Then, use the variable within the square bracket notation
// to assign a new value to the color property in
// myCar.

var add = "color";
car["color"] = "NavyBlue";
console.log(car);
// Use that same variable and assign a new property string value to it, such as
// forSale . Use the bracket notation once again to assign a new value to the
// forSale property to indicate whether the car is available for purchase.

var add = "available";
car["available"] = true;
console.log(car)

let n = car.model;
console.log(n);

let v = car.carName;
console.log(v);

let p = car.available;
console.log(p);



